﻿using ASP.Net.UnitsNetSerializationExamples.Application.Login;
using ASP.Net.UnitsNetSerializationExamples.Domain;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace ASP.Net.UnitsNetSerializationExamples.Controllers;

[ApiController]
[Route("[controller]")]
public class UserNameController : ControllerBase
{
    private readonly ISender _sender;
    private readonly IUserNameRepository _userNameRepository;

    public UserNameController(ISender sender, IUserNameRepository userNameRepository)
    {
        _sender = sender;
        _userNameRepository = userNameRepository;
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetUserName(int id)
    {
        var userName = await _userNameRepository.GetUserNameAsync(id);
        if (userName == null)
        {
            return NotFound();
        }
        return Ok(userName);
    }

    [HttpGet]
    public async Task<IActionResult> GetAllUserNames()
    {
        var userNames = await _userNameRepository.GetAllUserNamesAsync();
        return Ok(userNames);
    }

    [HttpPost("login")]
    public async Task<IActionResult> LoginUserName([FromBody] LoginRequest request, CancellationToken cancellationToken)
    {
        var command = new LoginCommand(request.UserId, request.PlainTextPassword);

        Result<string> tokenResult = await _sender.Send(command, cancellationToken);
    
        if (tokenResult.IsFailure)
        {
            return BadRequest(tokenResult.Error);
        }
    
        return Ok(tokenResult.Value);
    }

    [HttpPost("add")]
    public async Task<IActionResult> AddUserName([FromBody] UserName userName)
    {
        await _userNameRepository.AddUserNameAsync(userName);
        return CreatedAtAction(nameof(GetUserName), new { id = userName.Id }, userName);
    }
}