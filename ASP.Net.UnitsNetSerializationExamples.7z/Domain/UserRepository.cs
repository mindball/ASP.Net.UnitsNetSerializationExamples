﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace ASP.Net.UnitsNetSerializationExamples.Domain;

public interface IUserNameRepository
{
    //TODO it is necessary to implement the CancelationToken
    Task<UserName> GetUserNameAsync(int id);
    Task<IEnumerable<UserName>> GetAllUserNamesAsync();
    Task AddUserNameAsync(UserName userName);
}


public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<UserName> UserNames { get; set; }
}

public class UserNameRepository : IUserNameRepository
{
    private readonly AppDbContext _context;
    private readonly IPasswordHasher _passwordHasher;

    public UserNameRepository(AppDbContext context, IPasswordHasher passwordHasher)
    {
        _context = context;
        _passwordHasher = passwordHasher;
    }

    public async Task<UserName> GetUserNameAsync(int id)
    {
        return await _context.UserNames.FindAsync(id);
    }

    public async Task<IEnumerable<UserName>> GetAllUserNamesAsync()
    {
        return await _context.UserNames.ToListAsync();
    }

    public async Task AddUserNameAsync(UserName userName)
    {
        userName.Password = _passwordHasher.Hash(userName.Password.HashedPassword);
        _context.UserNames.Add(userName);
        await _context.SaveChangesAsync();
    }
}