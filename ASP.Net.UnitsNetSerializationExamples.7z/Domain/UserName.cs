﻿namespace ASP.Net.UnitsNetSerializationExamples.Domain
{
    public class UserName
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public Password Password { get; set; }
    }
}
