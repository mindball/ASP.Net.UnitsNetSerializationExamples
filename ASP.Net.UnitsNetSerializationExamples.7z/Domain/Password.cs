﻿using System.Security.Cryptography;

namespace ASP.Net.UnitsNetSerializationExamples.Domain;


public interface IPasswordHasher
{
    Password Hash(string plainTextPassword);
    bool Verify(string plainTextPassword, Password storedPassword);
}

public sealed class PasswordHasher : IPasswordHasher
{
    private const int SaltSize = 16;
    private const int HashSize = 32;
    private const int Iterations = 100000;

    private readonly HashAlgorithmName _hashAlgorithmName = HashAlgorithmName.SHA512;

    public Password Hash(string plainTextPassword)
    {
        if (string.IsNullOrWhiteSpace(plainTextPassword))
            throw new ArgumentException("Password cannot be empty.", nameof(plainTextPassword));

        byte[] salt = RandomNumberGenerator.GetBytes(SaltSize);
        byte[] hash = Rfc2898DeriveBytes.Pbkdf2(plainTextPassword, salt, Iterations, _hashAlgorithmName, HashSize);
        return Password.Create(Convert.ToBase64String(hash), Convert.ToBase64String(salt));
    }

    public bool Verify(string plainTextPassword, Password storedPassword)
    {
        if (storedPassword.IsPlainText)
        {
            return storedPassword.HashedPassword == plainTextPassword;
        }

        byte[] salt = Convert.FromBase64String(storedPassword.Salt);
        byte[] hash = Rfc2898DeriveBytes.Pbkdf2(plainTextPassword, salt, Iterations, _hashAlgorithmName, HashSize);
        return CryptographicOperations.FixedTimeEquals(hash, Convert.FromBase64String(storedPassword.HashedPassword));
    }
}

public readonly struct Password : IEquatable<Password>
{
    public string HashedPassword { get; }
    public string Salt { get; }

    public bool IsPlainText => Salt == null;

    private Password(string hashedPassword, string salt = null)
    {
        if (string.IsNullOrWhiteSpace(hashedPassword))
            throw new ArgumentException("Password cannot be empty.", nameof(hashedPassword));

        HashedPassword = hashedPassword;
        Salt = salt;
    }

    public static Password Create(string hashedPassword, string salt)
    {
        return new Password(hashedPassword, salt);
    }

    public static Password FromPlainText(string plainTextPassword)
    {
        return new Password(plainTextPassword);
    }

    public override bool Equals(object obj) => obj is Password other && Equals(other);

    public bool Equals(Password other) => HashedPassword == other.HashedPassword && Salt == other.Salt;

    public override int GetHashCode() => HashCode.Combine(HashedPassword, Salt);

    public override string ToString() => IsPlainText ? HashedPassword : $"{HashedPassword}:{Salt}";

    public static bool operator ==(Password left, Password right) => left.Equals(right);
    public static bool operator !=(Password left, Password right) => !left.Equals(right);
}

/* (Storing in Database):
 * IPasswordHasher passwordHasher = new PasswordHasher();
 * Password hashedPassword = passwordHasher.Hash(plainTextPassword);
 * Save to database: storedPassword.HashedPassword, storedPassword.Salt
 *
 * User Login (Verifying with Stored Hash:
 * string loginAttempt = "MySecureP@ssword";
 * Retrieve storedPasswordFromDB from database by username
 * bool isValid = passwordHasher.Verify(loginAttempt, storedPasswordFromDB);
 */