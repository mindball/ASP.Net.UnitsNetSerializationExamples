using ASP.Net.UnitsNetSerializationExamples.Application.Abstraction;
using ASP.Net.UnitsNetSerializationExamples.Application.Login;
using ASP.Net.UnitsNetSerializationExamples.Authentication;
using ASP.Net.UnitsNetSerializationExamples.Domain;
using ASP.Net.UnitsNetSerializationExamples.Extensions;
using ASP.Net.UnitsNetSerializationExamples.OptionSetup;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using UnitsNet.Serialization.JsonNet;
using JsonConverter = Newtonsoft.Json.JsonConverter;

var builder = WebApplication.CreateBuilder(args);

var converterType = builder.Configuration.GetSection("JsonConverter:Type").Value;
var converterTypeName = Type.GetType(converterType)?.FullName;
JsonConverter globalJsonConverter = converterTypeName == typeof(AbbreviatedUnitsConverter).FullName
    ? new AbbreviatedUnitsConverter()
    : new UnitsNetIQuantityJsonConverter();

builder.Services.AddCustomJson(globalJsonConverter);
builder.Services.AddCustomSwagger(globalJsonConverter);

// builder.Services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(ASP.Net.UnitsNetSerializationExamples.AssemblyReference.Assembly));
//
//
// builder.Services.AddDbContext<AppDbContext>(options =>
//     options.UseInMemoryDatabase("InMemoryDb"));
//
// builder.Services.AddScoped<IPasswordHasher, PasswordHasher>();
// builder.Services.AddScoped<IUserNameRepository, UserNameRepository>();
// builder.Services.AddScoped<IJwtProvider, JwtProvider>();
// builder.Services.AddScoped<ICommandHandler<LoginCommand, string>, LoginCommandHandler>();
//
// builder.Services.ConfigureOptions<JwtOptionsSetup>();
// builder.Services.ConfigureOptions<JwtBearerOptionsSetup>();
// builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer();

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();

app.UseAuthentication();
app.UseAuthorization();


app.MapControllers();

app.Run();


