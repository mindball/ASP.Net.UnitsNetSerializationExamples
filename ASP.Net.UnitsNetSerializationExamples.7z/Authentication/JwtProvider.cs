﻿using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using ASP.Net.UnitsNetSerializationExamples.Application.Abstraction;
using ASP.Net.UnitsNetSerializationExamples.Domain;
using ASP.Net.UnitsNetSerializationExamples.OptionSetup;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;

namespace ASP.Net.UnitsNetSerializationExamples.Authentication;

internal sealed class JwtProvider : IJwtProvider
{
    private readonly JwtSettings _jwtSettings;

    public JwtProvider(IOptions<JwtSettings> jwtSettings)
    {
        _jwtSettings = jwtSettings.Value;
    }
    
    public string GenerateToken(UserName userName)
    {
        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwtSettings.SecretKey));
        var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
        // claims are key-value pairs that are included in the token payload. They provide information about the user or the token itself.
        // Claims are used to convey information between the token issuer and the token consumer (e.g., a client and a server).
        var claims = new List<Claim>
        {
            new Claim(JwtRegisteredClaimNames.Sub, userName.Id.ToString()),
            new Claim(JwtRegisteredClaimNames.Email, userName.Email)
        };
        
        var token = new JwtSecurityToken(
            issuer: _jwtSettings.Issuer,
            audience: _jwtSettings.Audience,
            claims: claims,
            expires: DateTime.UtcNow.AddMinutes(60),
            signingCredentials: creds);

        return new JwtSecurityTokenHandler().WriteToken(token);
    }
}