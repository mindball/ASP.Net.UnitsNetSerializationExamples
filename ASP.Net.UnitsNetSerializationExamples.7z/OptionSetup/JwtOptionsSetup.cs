﻿using ASP.Net.UnitsNetSerializationExamples.Authentication;
using Microsoft.Extensions.Options;

namespace ASP.Net.UnitsNetSerializationExamples.OptionSetup;

public class JwtOptionsSetup : IConfigureOptions<JwtSettings>
{
    private const string JwtSectionName = "JWT";
    private readonly IConfiguration _configuration;

    public JwtOptionsSetup(IConfiguration configuration)
    {
        _configuration = configuration;
    }

    public void Configure(JwtSettings options)
    {
        _configuration.GetSection(JwtSectionName).Bind(options);
    }

}