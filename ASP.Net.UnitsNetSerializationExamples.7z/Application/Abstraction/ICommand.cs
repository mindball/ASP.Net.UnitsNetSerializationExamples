﻿using ASP.Net.UnitsNetSerializationExamples.Domain;
using MediatR;

namespace ASP.Net.UnitsNetSerializationExamples.Application.Abstraction;

public interface ICommand<TResponse> : IRequest<Result<TResponse>>;

public interface ICommandHandler<TCommand, TResponse>
    : IRequestHandler<TCommand, Result<TResponse>>
    where TCommand : ICommand<TResponse>;
