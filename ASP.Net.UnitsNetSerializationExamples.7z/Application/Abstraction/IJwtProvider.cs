﻿using ASP.Net.UnitsNetSerializationExamples.Domain;

namespace ASP.Net.UnitsNetSerializationExamples.Application.Abstraction;

public interface IJwtProvider
{
    string GenerateToken(UserName userName);
}