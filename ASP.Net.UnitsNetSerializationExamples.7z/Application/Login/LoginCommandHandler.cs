﻿using System.Windows.Input;
using ASP.Net.UnitsNetSerializationExamples.Application.Abstraction;
using ASP.Net.UnitsNetSerializationExamples.Domain;

namespace ASP.Net.UnitsNetSerializationExamples.Application.Login;

public record LoginCommand(int UserId, string PlainTextPassword) : ICommand<string>;


public record LoginRequest(int UserId, string PlainTextPassword);


internal sealed class LoginCommandHandler : ICommandHandler<LoginCommand, string>
{
    private readonly IUserNameRepository _repository;
    private readonly IJwtProvider _jwtProvider;
    private readonly IPasswordHasher _passwordHasher;

    public LoginCommandHandler(IUserNameRepository repository, IJwtProvider jwtProvider, IPasswordHasher passwordHasher)
    {
        _repository = repository;
        _jwtProvider = jwtProvider;
        _passwordHasher = passwordHasher;
    }

    public async Task<Result<string>> Handle(LoginCommand request, CancellationToken cancellationToken)
    {
        var user = await _repository.GetUserNameAsync(request.UserId);
        if (user is null)
        {
            return Result.Failure<string>(new Error("401", "Invalid credentials"));
        }

        //TODO: return same Result.Failure when the password is unmatched. It is necessary to implement the hash password verification
        if (!_passwordHasher.Verify(request.PlainTextPassword, user.Password))
        {
            return Result.Failure<string>(new Error("401", "Invalid password credentials"));
        }
        
        string token = _jwtProvider.GenerateToken(user);

        return token;
    }
}