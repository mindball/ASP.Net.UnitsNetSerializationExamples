﻿using System.Reflection;

namespace ASP.Net.UnitsNetSerializationExamples;

public static class AssemblyReference
{
    public static readonly Assembly Assembly = typeof(AssemblyReference).Assembly;
}